//>>built
define("dojox/timing",["./timing/_base"],function(_1){
return _1;
});
