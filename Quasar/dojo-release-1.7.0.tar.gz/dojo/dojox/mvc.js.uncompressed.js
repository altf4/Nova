//>>built
define("dojox/mvc", ["./mvc/_base"], function(dxmvc){
	// module:
	//		dojox/mvc
	// summary:
	//		Adds elements of MVC support to Dojo.

	return dxmvc;
});
