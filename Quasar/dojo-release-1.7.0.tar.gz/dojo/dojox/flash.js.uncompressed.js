//>>built
// wrapped by build app
define("dojox/flash", ["dijit","dojo","dojox","dojo/require!dojox/flash/_base"], function(dijit,dojo,dojox){
dojo.provide("dojox.flash");
dojo.require("dojox.flash._base");

});
