//>>built
define("dojox/validate", ["./validate/_base"], function(validate){
	/*===== 
	dojox.validate = {
		// summary: Additional validation routines for Strings, Numbers, credit cards, and other esoteric needs. 
	};
	=====*/
	return validate;
});
