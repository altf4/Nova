//>>built
// wrapped by build app
define("dojox/widget/gauge/BarIndicator", ["dijit","dojo","dojox","dojo/require!dojox/gauges/BarIndicator"], function(dijit,dojo,dojox){
dojo.provide('dojox.widget.gauge.BarIndicator');
dojo.require('dojox.gauges.BarIndicator');

dojox.widget.gauge.BarIndicator = dojox.gauges.BarIndicator;

});
