//>>built
define(["dijit","dojo","dojox","dojo/require!dojox/gauges/AnalogArcIndicator"],function(_1,_2,_3){
_2.provide("dojox.widget.gauge.AnalogArcIndicator");
_2.require("dojox.gauges.AnalogArcIndicator");
_3.widget.gauge.AnalogArcIndicator=_3.gauges.AnalogArcIndicator;
});
