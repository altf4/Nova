//>>built
define(["dijit","dojo","dojox","dojo/require!dojox/gauges/AnalogArrowIndicator"],function(_1,_2,_3){
_2.provide("dojox.widget.gauge.AnalogArrowIndicator");
_2.require("dojox.gauges.AnalogArrowIndicator");
_3.widget.gauge.AnalogArrowIndicator=_3.gauges.AnalogArrowIndicator;
});
