//>>built
define(["dijit","dojo","dojox","dojo/require!dojox/gauges/_Gauge"],function(_1,_2,_3){
_2.provide("dojox.widget.gauge._Gauge");
_2.require("dojox.gauges._Gauge");
_3.widget.gauge._Gauge=_3.gauges._Gauge;
_3.widget.gauge.Range=_3.gauges.Range;
_3.widget.gauge._indicator=_3.gauges._indicator;
});
