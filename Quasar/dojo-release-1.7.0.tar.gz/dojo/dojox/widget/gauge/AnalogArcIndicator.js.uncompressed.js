//>>built
// wrapped by build app
define("dojox/widget/gauge/AnalogArcIndicator", ["dijit","dojo","dojox","dojo/require!dojox/gauges/AnalogArcIndicator"], function(dijit,dojo,dojox){
dojo.provide('dojox.widget.gauge.AnalogArcIndicator');
dojo.require("dojox.gauges.AnalogArcIndicator");

dojox.widget.gauge.AnalogArcIndicator = dojox.gauges.AnalogArcIndicator;

});
