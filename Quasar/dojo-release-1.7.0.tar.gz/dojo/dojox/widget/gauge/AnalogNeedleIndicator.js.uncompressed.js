//>>built
// wrapped by build app
define("dojox/widget/gauge/AnalogNeedleIndicator", ["dijit","dojo","dojox","dojo/require!dojox/gauges/AnalogNeedleIndicator"], function(dijit,dojo,dojox){
dojo.provide('dojox.widget.gauge.AnalogNeedleIndicator');
dojo.require('dojox.gauges.AnalogNeedleIndicator');

dojox.widget.gauge.AnalogNeedleIndicator = dojox.gauges.AnalogNeedleIndicator;

});
