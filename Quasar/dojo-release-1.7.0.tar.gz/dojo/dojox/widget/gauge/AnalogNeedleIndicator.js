//>>built
define(["dijit","dojo","dojox","dojo/require!dojox/gauges/AnalogNeedleIndicator"],function(_1,_2,_3){
_2.provide("dojox.widget.gauge.AnalogNeedleIndicator");
_2.require("dojox.gauges.AnalogNeedleIndicator");
_3.widget.gauge.AnalogNeedleIndicator=_3.gauges.AnalogNeedleIndicator;
});
