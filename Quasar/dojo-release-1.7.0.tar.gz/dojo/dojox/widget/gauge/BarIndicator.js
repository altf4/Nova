//>>built
define(["dijit","dojo","dojox","dojo/require!dojox/gauges/BarIndicator"],function(_1,_2,_3){
_2.provide("dojox.widget.gauge.BarIndicator");
_2.require("dojox.gauges.BarIndicator");
_3.widget.gauge.BarIndicator=_3.gauges.BarIndicator;
});
