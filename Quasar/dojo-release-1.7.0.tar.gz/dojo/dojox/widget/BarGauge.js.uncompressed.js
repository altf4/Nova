//>>built
// wrapped by build app
define("dojox/widget/BarGauge", ["dijit","dojo","dojox","dojo/require!dojox/widget/gauge/_Gauge,dojox/gauges/BarGauge"], function(dijit,dojo,dojox){
// backward compatibility for dojox.widget.BarGauge
dojo.provide("dojox.widget.BarGauge");
dojo.require("dojox.widget.gauge._Gauge");
dojo.require("dojox.gauges.BarGauge");
dojox.widget.BarGauge = dojox.gauges.BarGauge;
dojox.widget.gauge.BarLineIndicator = dojox.gauges.BarLineIndicator;

});
