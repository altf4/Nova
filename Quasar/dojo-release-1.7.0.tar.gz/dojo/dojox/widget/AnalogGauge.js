//>>built
define(["dijit","dojo","dojox","dojo/require!dojox/widget/gauge/_Gauge,dojox/gauges/AnalogGauge"],function(_1,_2,_3){
_2.provide("dojox.widget.AnalogGauge");
_2.require("dojox.widget.gauge._Gauge");
_2.require("dojox.gauges.AnalogGauge");
_3.widget.AnalogGauge=_3.gauges.AnalogGauge;
_3.widget.gauge.AnalogLineIndicator=_3.gauges.AnalogLineIndicator;
});
