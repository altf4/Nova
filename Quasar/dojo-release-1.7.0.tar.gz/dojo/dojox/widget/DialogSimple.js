//>>built
define("dojox/widget/DialogSimple",["dojo","dijit","dojox","dijit/Dialog","dojox/layout/ContentPane"],function(_1,_2,_3){
_1.getObject("widget",true,_3);
return _1.declare("dojox.widget.DialogSimple",[_3.layout.ContentPane,_2._DialogBase],{});
});
