//>>built
define(["dijit","dojo","dojox","dojo/require!dojox/widget/gauge/_Gauge,dojox/gauges/BarGauge"],function(_1,_2,_3){
_2.provide("dojox.widget.BarGauge");
_2.require("dojox.widget.gauge._Gauge");
_2.require("dojox.gauges.BarGauge");
_3.widget.BarGauge=_3.gauges.BarGauge;
_3.widget.gauge.BarLineIndicator=_3.gauges.BarLineIndicator;
});
