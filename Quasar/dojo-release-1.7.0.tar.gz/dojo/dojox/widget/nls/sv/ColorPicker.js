//>>built
define(
//begin v1.x content
({
hueLabel: "n",
saturationLabel: "m",
valueLabel: "l", /* aka intensity or brightness */
huePickerTitle: "Välj färgton",
saturationPickerTitle: "Välj mättnad"
})
);
