//>>built
define(
//begin v1.x content
({
next: "Nästa",
previous: "Föregående",
done: "Stäng"
})
//end v1.x content
);
