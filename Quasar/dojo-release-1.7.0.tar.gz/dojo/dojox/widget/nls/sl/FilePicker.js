//>>built
define(
({
name: "Ime",
path: "Pot",
size: "Velikost (v bajtih)"
})


);