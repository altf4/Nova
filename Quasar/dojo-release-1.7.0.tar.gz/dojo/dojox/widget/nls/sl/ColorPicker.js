//>>built
define(
//begin v1.x content
({
huePickerTitle: "Izbirnik odtenka ",
saturationPickerTitle: "Izbirnik nasičenosti"
})
);
