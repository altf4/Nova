//>>built
define(
//begin v1.x content
({
next: "Naprej",
previous: "Nazaj",
done: "Opravljeno"
})
//end v1.x content
);
