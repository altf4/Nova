//>>built
define(
//begin v1.x content
({
huePickerTitle: "محدد تدرج اللون",
saturationPickerTitle: "محدد درجة التشبع"
})
//end v1.x content
);
