//>>built
define(
({
name: "الاسم",
path: "‏المسار‏",
size: "الحجم (بالبايت)"
})


);