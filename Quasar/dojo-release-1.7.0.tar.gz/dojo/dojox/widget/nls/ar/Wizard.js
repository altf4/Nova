//>>built
define(
//begin v1.x content
({
next: "تالي",
previous: "‏سابق‏",
done: "اتمام"
})
//end v1.x content
);
