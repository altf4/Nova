//>>built
define({root:
({
name: "Name",
path: "Path",
size: "Size (in bytes)"
})
,
"da":1,
"pt-pt":1,
"es":1,
"hu":1,
"de":1,
"sk":1,
"sl":1,
"pl":1,
"pt":1,
"sv":1,
"ca":1,
"zh-tw":1,
"ar":1,
"fi":1,
"ro":1,
"nb":1,
"ru":1,
"zh":1,
"fr":1,
"it":1,
"th":1,
"he":1,
"cs":1,
"nl":1,
"kk":1,
"el":1,
"tr":1,
"ko":1,
"ja":1
});
