//>>built
define(
({
name: "Όνομα",
path: "Διαδρομή",
size: "Μέγεθος (σε bytes)"
})

);