//>>built
define(
//begin v1.x content
({
next: "Επόμενο",
previous: "Προηγούμενο",
done: "Ολοκλήρωση"
})
//end v1.x content
);
