//>>built
define(
//begin v1.x content
({
redLabel: "κ",
greenLabel: "π",
blueLabel: "μ",
hueLabel: "α",
saturationLabel: "κ",
valueLabel: "τ", /* aka intensity or brightness */
hexLabel: "16-αδικό",
huePickerTitle: "Επιλογή απόχρωσης",
saturationPickerTitle: "Επιλογή κορεσμού"
})
);
