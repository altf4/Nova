//>>built
define(
//begin v1.x content
({
next: "다음",
previous: "이전",
done: "완료"
})
//end v1.x content
);
