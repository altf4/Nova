//>>built
define(
({
name: "שם",
path: "נתיב",
size: "גודל (בבתים)"
})

);