//>>built
define(
//begin v1.x content
({
next: "הבא",
previous: "הקודם",
done: "סיום"
})
//end v1.x content
);
