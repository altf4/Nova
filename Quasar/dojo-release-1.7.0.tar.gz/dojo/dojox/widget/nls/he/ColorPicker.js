//>>built
define(
//begin v1.x content
({
redLabel: "א",
greenLabel: "י",
blueLabel: "כ",
hueLabel: "ג",
saturationLabel: "ר",
valueLabel: "ע", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "הקס",
huePickerTitle: "בורר גוון",
saturationPickerTitle: "בורר רוויה"
})
);
