//>>built
define(
({
name: "Nazwa",
path: "Ścieżka",
size: "Wielkość (w bajtach)"
})

);