//>>built
define(
//begin v1.x content
({
redLabel: "c",
greenLabel: "z",
blueLabel: "n",
hueLabel: "barwa",
saturationLabel: "nas.",
valueLabel: "jas.", /* aka intensity or brightness */
hexLabel: "szesnastkowe",
huePickerTitle: "Selektor barwy",
saturationPickerTitle: "Selektor nasycenia"
})
);
