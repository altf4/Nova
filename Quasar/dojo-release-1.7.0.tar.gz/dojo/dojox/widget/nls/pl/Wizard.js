//>>built
define(
//begin v1.x content
({
next: "Dalej",
previous: "Wstecz",
done: "Gotowe"
})
//end v1.x content
);
