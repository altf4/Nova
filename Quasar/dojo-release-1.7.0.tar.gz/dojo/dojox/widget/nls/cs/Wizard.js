//>>built
define(
//begin v1.x content
({
next: "Další",
previous: "Předchozí",
done: "Hotovo"
})
//end v1.x content
);
