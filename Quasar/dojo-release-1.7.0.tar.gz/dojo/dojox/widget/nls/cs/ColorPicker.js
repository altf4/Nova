//>>built
define(
//begin v1.x content
({
redLabel: "č",
greenLabel: "z",
blueLabel: "m",
hueLabel: "o",
saturationLabel: "n",
valueLabel: "j", /* aka intensity or brightness */
huePickerTitle: "Selektor odstínu",
saturationPickerTitle: "Selektor sytosti"
})
);
