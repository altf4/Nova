//>>built
define(
//begin v1.x content
({
next: "Következő",
previous: "Előző",
done: "Kész"
})
//end v1.x content
);
