//>>built
define(
//begin v1.x content
({
huePickerTitle: "Árnyalat kiválasztó",
saturationPickerTitle: "Telítettség kiválasztó"
})
);
