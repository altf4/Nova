//>>built
define(
//begin v1.x content
({
hueLabel: "t",
saturationLabel: "i",
valueLabel: "h", /* aka intensity or brightness */
huePickerTitle: "Tint selecteren",
saturationPickerTitle: "Intensiteit selecteren"
})
);
