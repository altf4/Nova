//>>built
define(
//begin v1.x content
({
next: "Volgende",
previous: "Vorige",
done: "Klaar"
})
//end v1.x content
);
