//>>built
define(
({
name: "Naam",
path: "Pad",
size: "Grootte (in bytes)"
})


);