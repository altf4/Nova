//>>built
define(
({
name: "Navn",
path: "Bane",
size: "Størrelse (i byte)"
})

);