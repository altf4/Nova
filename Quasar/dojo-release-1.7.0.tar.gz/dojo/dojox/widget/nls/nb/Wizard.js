//>>built
define(
//begin v1.x content
({
next: "Neste",
previous: "Forrige",
done: "Ferdig"
})
//end v1.x content
);
