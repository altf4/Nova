//>>built
define(
//begin v1.x content
({
hexLabel: "十六进制",
huePickerTitle: "色彩选择器",
saturationPickerTitle: "饱和度选择器"
})
);