//>>built
define(
({
name: "名称",
path: "路径",
size: "大小（字节）"
})

);