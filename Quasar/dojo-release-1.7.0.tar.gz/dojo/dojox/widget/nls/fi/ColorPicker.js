//>>built
define(
//begin v1.x content
({
huePickerTitle: "Sävyn valitsin",
saturationPickerTitle: "Kylläisyyden valitsin"
})
);
