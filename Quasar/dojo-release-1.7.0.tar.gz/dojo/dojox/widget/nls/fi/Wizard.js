//>>built
define(
//begin v1.x content
({
next: "Seuraava",
previous: "Edellinen",
done: "Valmis"
})
//end v1.x content
);
