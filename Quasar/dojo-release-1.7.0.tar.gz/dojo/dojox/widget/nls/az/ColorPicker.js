//>>built
define(
//begin v1.x content
({
	"redLabel" : "q",
	"valueLabel" : "d",
	"hexLabel" : "onaltılıq",
	"hueLabel" : "ç",
	"saturationLabel" : "d",
	"greenLabel" : "y",
	"blueLabel" : "m",
	"saturationPickerTitle" : "Doldurmaq seçimi",
	"huePickerTitle" : "Çalar seçimi",
	"degLabel" : "°"
})
//end v1.x content
);
