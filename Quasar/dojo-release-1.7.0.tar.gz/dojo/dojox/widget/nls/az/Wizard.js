//>>built
define(
//begin v1.x content
({
	"next" : "Irəli",
	"done" : "Qurtardı",
	"previous" : "Geri"
})
//end v1.x content
);
