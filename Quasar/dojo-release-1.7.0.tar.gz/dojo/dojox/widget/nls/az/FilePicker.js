//>>built
define(
//begin v1.x content
({
	"name" : "Ad",
	"size" : "Həcmi (bayt cinsindən)",
	"path" : "Yol"
})
//end v1.x content
);
