//>>built
define(
//begin v1.x content
({
next: "Далее",
previous: "Назад",
done: "Готово"
})
//end v1.x content
);
