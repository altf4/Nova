//>>built
define(
//begin v1.x content
({
redLabel: "к",
greenLabel: "з",
blueLabel: "с",
hueLabel: "о",
saturationLabel: "н",
valueLabel: "з", /* aka intensity or brightness */
hexLabel: "шест",
huePickerTitle: "Выбор оттенка",
saturationPickerTitle: "Выбор насыщенности"
})
);
