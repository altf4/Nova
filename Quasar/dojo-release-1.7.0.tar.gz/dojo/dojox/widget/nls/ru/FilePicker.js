//>>built
define(
({
name: "Имя",
path: "Путь",
size: "Размер (байт)"
})

);