//>>built
define(
//begin v1.x content
({
next: "Următor",
previous: "Anterior",
done: "Gata"
})
//end v1.x content
);
