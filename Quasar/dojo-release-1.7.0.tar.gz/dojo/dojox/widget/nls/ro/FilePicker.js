//>>built
define(
({
name: "Nume",
path: "Cale ",
size: "Dimensiune (în octeţi)"
})


);