//>>built
define(
//begin v1.x content
({
huePickerTitle: "Selector nuanţă",
saturationPickerTitle: "Selector saturaţie"
})
);
