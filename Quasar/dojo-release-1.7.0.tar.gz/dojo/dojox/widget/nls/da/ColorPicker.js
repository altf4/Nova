//>>built
define(
//begin v1.x content
({
huePickerTitle: "Vælg nuance",
saturationPickerTitle: "Vælg mætning"
})
);
