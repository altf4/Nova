//>>built
define(
//begin v1.x content
({
next: "Næste",
previous: "Forrige",
done: "Udført"
})
//end v1.x content
);
