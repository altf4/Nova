//>>built
define(
//begin v1.x content
({
next: "Próximo",
previous: "Anterior",
done: "Concluído"
})
//end v1.x content
);
