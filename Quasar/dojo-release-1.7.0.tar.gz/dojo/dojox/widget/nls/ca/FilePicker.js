//>>built
define(
({
name: "Nom",
path: "Camí d'accés",
size: "Mida (en bytes)"
})


);