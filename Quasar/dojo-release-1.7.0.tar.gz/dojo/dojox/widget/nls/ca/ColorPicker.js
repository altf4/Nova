//>>built
define(
//begin v1.x content
({
redLabel: "v",
greenLabel: "e",
hueLabel: "m",
huePickerTitle: "Selector de matís",
saturationPickerTitle: "Selector de saturació"
})
);