//>>built
define(
//begin v1.x content
({
redLabel: "e",
greenLabel: "v",
blueLabel: "a",
hueLabel: "t",
valueLabel: "val", /* aka intensity or brightness */
huePickerTitle: "Selector de tonalidade",
saturationPickerTitle: "Selector de saturação"
})
);
