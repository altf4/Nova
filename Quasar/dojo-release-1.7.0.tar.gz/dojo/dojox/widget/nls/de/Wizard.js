//>>built
define(
//begin v1.x content
({
next: "Weiter",
previous: "Zurück",
done: "Fertig"
})
//end v1.x content
);
