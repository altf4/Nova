//>>built
define(
//begin v1.x content
({
huePickerTitle: "Farbtonauswahl",
saturationPickerTitle: "Sättigungsauswahl"
})
);
