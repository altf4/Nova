//>>built
define(
({
name: "Name",
path: "Pfad",
size: "Größe (in Byte)"
})

);