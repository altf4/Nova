//>>built
define(
({
name: "Атауы",
path: "Жол",
size: "Өлшемі (байт)"
})


);