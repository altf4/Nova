//>>built
define(
//begin v1.x content
({
redLabel: "r",
greenLabel: "д",
blueLabel: "ә",
hueLabel: "е",
saturationLabel: "ң",
valueLabel: "п", /* aka intensity or brightness */
hexLabel: "алтылық",
huePickerTitle: "Реңкті іріктеу",
saturationPickerTitle: "Қанықтықты іріктеу"
})
);
