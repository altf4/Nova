//>>built
define(
//begin v1.x content
({
next: "İleri",
previous: "Geri",
done: "Bitti"
})
//end v1.x content
);
