//>>built
define(
//begin v1.x content
({
redLabel: "k",
greenLabel: "y",
blueLabel: "m",
hueLabel: "t",
saturationLabel: "d",
valueLabel: "d", /* aka intensity or brightness */
hexLabel: "onaltılı",
huePickerTitle: "Ton Seçici",
saturationPickerTitle: "Doygunluk Seçici"
})
);
