//>>built
define(
({
name: "Nome",
path: "Percorso",
size: "Dimensione (in byte)"
})

);