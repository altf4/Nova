//>>built
define(
//begin v1.x content
({
next: "次へ",
previous: "前へ",
done: "完了"
})
//end v1.x content
);
