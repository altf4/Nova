//>>built
define(
//begin v1.x content
({
hexLabel: "16 進",
huePickerTitle: "色調セレクター",
saturationPickerTitle: "彩度セレクター"
})
);