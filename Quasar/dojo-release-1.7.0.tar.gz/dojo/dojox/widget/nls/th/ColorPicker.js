//>>built
define(
//begin v1.x content
({
redLabel: "อาร์",
greenLabel: "จี",
blueLabel: "บี",
hueLabel: "เอช",
saturationLabel: "เอส",
valueLabel: "วี", /* aka intensity or brightness */
huePickerTitle: "ตัวเลือกสี",
saturationPickerTitle: "ตัวเลือกความอิ่มของสี"
})
);
