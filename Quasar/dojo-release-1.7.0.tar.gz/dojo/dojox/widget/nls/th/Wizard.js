//>>built
define(
//begin v1.x content
({
next: "ถัดไป",
previous: "ก่อนหน้า",
done: "เสร็จสิ้น"
})
//end v1.x content
);
