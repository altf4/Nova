//>>built
define(
({
name: "ชื่อ",
path: "พาธ",
size: "ขนาด (ไบต์)"
})


);