//>>built
define(
//begin v1.x content
({
hexLabel: "十六進位",
huePickerTitle: "色調選取元",
saturationPickerTitle: "飽和度選取元"
})
);