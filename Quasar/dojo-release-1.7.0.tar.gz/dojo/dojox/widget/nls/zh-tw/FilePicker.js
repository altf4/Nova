//>>built
define(
({
name: "名稱",
path: "路徑",
size: "大小 (以位元組為單位)"
})

);