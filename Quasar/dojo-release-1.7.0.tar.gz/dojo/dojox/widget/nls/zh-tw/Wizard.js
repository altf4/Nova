//>>built
define(
//begin v1.x content
({
next: "下一步",
previous: "上一步",
done: "完成"
})
//end v1.x content
);
