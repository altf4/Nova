//>>built
define(
//begin v1.x content
({
next: "Suivant",
previous: "Précédent",
done: "Terminé"
})
//end v1.x content
);
