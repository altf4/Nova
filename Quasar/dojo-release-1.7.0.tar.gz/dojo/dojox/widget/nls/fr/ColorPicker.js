//>>built
define(
//begin v1.x content
({
greenLabel: "v",
hueLabel: "t",
huePickerTitle: "Sélecteur de teinte",
saturationPickerTitle: "Sélecteur de saturation"
})
);
