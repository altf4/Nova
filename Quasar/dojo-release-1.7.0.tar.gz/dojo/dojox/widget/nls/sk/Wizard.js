//>>built
define(
//begin v1.x content
({
next: "Ďalej",
previous: "Späť",
done: "Hotovo"
})
//end v1.x content
);
