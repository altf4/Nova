//>>built
define("dojox/mvc/Group",["dojo/_base/declare","dijit/_WidgetBase"],function(_1,_2){
return _1("dojox.mvc.Group",[_2],{});
});
