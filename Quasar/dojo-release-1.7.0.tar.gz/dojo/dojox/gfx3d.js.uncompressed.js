//>>built
// AMD-ID "dojox/gfx3d"
define("dojox/gfx3d", ["dojo/_base/kernel","dojox","./gfx3d/matrix","./gfx3d/_base","./gfx3d/object"], function(dojo,dojox) {
dojo.getObject("gfx3d", true, dojox);

return dojox.gfx3d;
});
