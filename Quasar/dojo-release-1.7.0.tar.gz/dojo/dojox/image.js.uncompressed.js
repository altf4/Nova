//>>built
define("dojox/image", ["./image/_base"], function(image){
	/*=====
	dojox.image = {
		// summary: Collection of image-related widgets and controls
	};
	=====*/
	return image;
});