//>>built
define(["dijit","dojo","dojox","dojo/require!dojox/wire/_base"],function(_1,_2,_3){
_2.provide("dojox.wire");
_2.require("dojox.wire._base");
});
