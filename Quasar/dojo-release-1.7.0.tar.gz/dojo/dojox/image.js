//>>built
define("dojox/image",["./image/_base"],function(_1){
return _1;
});
