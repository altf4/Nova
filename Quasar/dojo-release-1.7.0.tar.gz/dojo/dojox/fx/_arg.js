//>>built
define("dojox/fx/_arg",["dojo/_base/lang"],function(_1){
var _2=_1.getObject("dojox.fx._arg",true);
_2.StyleArgs=function(_3){
this.node=_3.node;
this.cssClass=_3.cssClass;
};
_2.ShadowResizeArgs=function(_4){
this.x=_4.x;
this.y=_4.y;
};
return _2;
});
