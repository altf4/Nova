//>>built
define("dojox/timing", ["./timing/_base"], function(timing){
	return timing;
});
