//>>built
define("dojox/html",["./html/_base"],function(_1){
return _1;
});
