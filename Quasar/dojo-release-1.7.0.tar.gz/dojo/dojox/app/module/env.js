//>>built
define("dojox/app/module/env",["dojo/_base/declare"],function(_1){
return _1(null,{mode:"",init:function(){
}});
});
